'use client'
import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { toast } from 'react-hot-toast'
import {
  CheckCircle2, XCircle, Clock, RotateCcw, Users, Search, LogOut,
  CalendarDays, BarChart3, Trash2, ShieldCheck, ChevronLeft, ChevronRight,
  AlertTriangle, TrendingUp, Building2, Filter,
} from 'lucide-react'
import {
  getUser, logoutApi, isAdmin,
  adminGetUsersApi, adminGetStatsApi,
  adminApproveApi, adminRejectApi, adminResetApi,
  adminGetBookingsApi, adminDeleteBookingApi, adminGetReportApi,
} from '@/lib/authService'

type Tab = 'members' | 'bookings' | 'report'
type StatusFilter = 'all' | 'pending' | 'approved' | 'rejected'

const STATUS_META: Record<string, { label: string; cls: string }> = {
  pending:  { label: 'Chờ duyệt', cls: 'bg-amber-100 text-amber-700' },
  approved: { label: 'Đã duyệt',  cls: 'bg-emerald-100 text-emerald-700' },
  rejected: { label: 'Từ chối',   cls: 'bg-red-100 text-red-600' },
}

const BOOKING_STATUS: Record<string, { label: string; cls: string }> = {
  upcoming: { label: 'Sắp tới',  cls: 'bg-blue-100 text-blue-700' },
  ongoing:  { label: 'Đang họp', cls: 'bg-emerald-100 text-emerald-700' },
  done:     { label: 'Đã xong',  cls: 'bg-gray-100 text-gray-500' },
}

function addDays(d: string, n: number) {
  const dt = new Date(d + 'T00:00:00'); dt.setDate(dt.getDate() + n)
  return `${dt.getFullYear()}-${String(dt.getMonth()+1).padStart(2,'0')}-${String(dt.getDate()).padStart(2,'0')}`
}

export default function AdminPage() {
  const router = useRouter()
  const user   = getUser()
  const [activeTab, setActiveTab] = useState<Tab>('members')

  useEffect(() => {
    if (!user || !isAdmin()) router.push('/login')
  }, [])

  const initials = user?.fullName?.split(' ').map((n: string) => n[0]).slice(-2).join('').toUpperCase() || 'AD'

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <aside className="w-56 bg-white border-r border-gray-100 shadow-sm flex flex-col flex-shrink-0">
        <div className="flex items-center gap-2.5 px-5 py-5 border-b border-gray-100">
          <div className="h-8 w-8 rounded-xl bg-indigo-600 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">V</div>
          <div>
            <p className="text-sm font-bold text-gray-800">Viên Chi Bảo</p>
            <p className="text-[10px] text-gray-400">Admin Panel</p>
          </div>
        </div>

        <nav className="flex-1 p-3 space-y-1">
          <p className="px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-gray-300 mb-1">Quản lý</p>

          {([
            { key: 'members',  icon: Users,       label: 'Duyệt thành viên' },
            { key: 'bookings', icon: CalendarDays, label: 'Quản lý đặt phòng' },
            { key: 'report',   icon: BarChart3,    label: 'Thống kê' },
          ] as { key: Tab; icon: any; label: string }[]).map(item => (
            <button key={item.key} onClick={() => setActiveTab(item.key)}
              className={`flex items-center gap-2.5 w-full px-3 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                activeTab === item.key
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-gray-500 hover:bg-gray-50 hover:text-gray-700'
              }`}>
              <item.icon className="h-4 w-4 flex-shrink-0" />
              {item.label}
            </button>
          ))}
        </nav>

        <div className="p-3 border-t border-gray-100">
          <div className="flex items-center gap-2.5 px-3 py-2 mb-1">
            <div className="h-8 w-8 rounded-full bg-indigo-100 text-indigo-600 text-xs font-bold flex items-center justify-center flex-shrink-0">{initials}</div>
            <div className="min-w-0">
              <p className="text-xs font-semibold text-gray-700 truncate">{user?.fullName}</p>
              <p className="text-[10px] text-gray-400">Administrator</p>
            </div>
          </div>
          <button onClick={async () => { await logoutApi(); router.push('/login') }}
            className="flex items-center gap-2 w-full px-3 py-2 rounded-lg text-xs text-gray-400 hover:text-gray-700 hover:bg-gray-50 transition-colors">
            <LogOut className="h-3.5 w-3.5" /> Đăng xuất
          </button>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {activeTab === 'members'  && <MembersTab />}
        {activeTab === 'bookings' && <BookingsTab />}
        {activeTab === 'report'   && <ReportTab />}
      </div>
    </div>
  )
}

/* ─────────────────────────────────────────────────────────────
   TAB 1: DUYỆT THÀNH VIÊN
───────────────────────────────────────────────────────────── */
function MembersTab() {
  const [users,        setUsers]        = useState<any[]>([])
  const [stats,        setStats]        = useState({ users: { pending: 0, approved: 0, rejected: 0, total: 0 }, bookings: { total: 0, today: 0, tang5: 0, tang6: 0 } })
  const [filter,       setFilter]       = useState<StatusFilter>('pending')
  const [search,       setSearch]       = useState('')
  const [loading,      setLoading]      = useState(true)
  const [actionId,     setActionId]     = useState<string | null>(null)
  const [modal,        setModal]        = useState<{ open: boolean; userId: string; name: string }>({ open: false, userId: '', name: '' })
  const [rejectReason, setRejectReason] = useState('')

  useEffect(() => { loadData() }, [filter])

  async function loadData() {
    setLoading(true)
    const [uRes, sRes] = await Promise.all([
      adminGetUsersApi(filter === 'all' ? undefined : filter),
      adminGetStatsApi(),
    ])
    if (uRes.success) setUsers(uRes.data)
    if (sRes.success) setStats(sRes.data)
    setLoading(false)
  }

  async function approve(id: string) {
    setActionId(id)
    const res = await adminApproveApi(id)
    if (!res.success) toast.error(res.message)
    else toast.success('Duyệt thành công!')
    await loadData(); setActionId(null)
  }

  async function confirmReject() {
    setActionId(modal.userId)
    const res = await adminRejectApi(modal.userId, rejectReason)
    if (!res.success) toast.error(res.message)
    else toast.success('Đã từ chối tài khoản!')
    setModal({ open: false, userId: '', name: '' }); setRejectReason('')
    await loadData(); setActionId(null)
  }

  async function revoke(id: string, name: string) {
    if (!confirm('Thu hồi quyền đặt phòng của ' + name + '?')) return
    setActionId(id)
    const res = await adminRejectApi(id, 'Quyền bị thu hồi bởi admin')
    if (!res.success) toast.error(res.message)
    else toast.success('Đã thu hồi quyền!')
    await loadData(); setActionId(null)
  }

  async function reset(id: string) {
    setActionId(id)
    const res = await adminResetApi(id)
    if (!res.success) toast.error(res.message)
    else toast.success('Đã đặt lại trạng thái chờ duyệt!')
    await loadData(); setActionId(null)
  }

  const filtered = users.filter(u =>
    u.fullName.toLowerCase().includes(search.toLowerCase()) ||
    u.email.toLowerCase().includes(search.toLowerCase()) ||
    (u.department || '').toLowerCase().includes(search.toLowerCase())
  )

  const u = stats.users

  return (
    <>
      <header className="h-14 bg-white border-b border-gray-100 px-6 flex items-center justify-between flex-shrink-0">
        <h1 className="text-base font-bold text-gray-800">Duyệt thành viên</h1>
        <span className="text-xs text-gray-400">Quản lý quyền đăng ký phòng họp</span>
      </header>

      <main className="flex-1 p-6 overflow-auto">
        {/* Stats */}
        <div className="grid grid-cols-4 gap-4 mb-6">
          {[
            { label: 'Tổng thành viên', val: u.total,    Icon: Users,        c: 'text-gray-600',    bg: 'bg-gray-100'   },
            { label: 'Chờ duyệt',       val: u.pending,  Icon: Clock,        c: 'text-amber-600',   bg: 'bg-amber-50'   },
            { label: 'Đã duyệt',        val: u.approved, Icon: CheckCircle2, c: 'text-emerald-600', bg: 'bg-emerald-50' },
            { label: 'Từ chối',         val: u.rejected, Icon: XCircle,      c: 'text-red-500',     bg: 'bg-red-50'     },
          ].map(s => (
            <div key={s.label} className="bg-white rounded-2xl border border-gray-100 p-4 flex items-center gap-3">
              <div className={`h-10 w-10 rounded-xl ${s.bg} flex items-center justify-center flex-shrink-0`}>
                <s.Icon className={`h-5 w-5 ${s.c}`} />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-800">{s.val}</p>
                <p className="text-xs text-gray-400 mt-0.5">{s.label}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Pending alert */}
        {u.pending > 0 && (
          <div className="mb-4 flex items-center gap-2.5 bg-amber-50 border border-amber-200 text-amber-700 rounded-xl px-4 py-3 text-sm">
            <AlertTriangle className="h-4 w-4 flex-shrink-0" />
            <span>Có <strong>{u.pending}</strong> tài khoản đang chờ duyệt</span>
          </div>
        )}

        {/* Table */}
        <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-gray-50 gap-4">
            <div className="flex gap-1 bg-gray-50 p-1 rounded-xl">
              {(['pending','approved','rejected','all'] as StatusFilter[]).map(f => (
                <button key={f} onClick={() => setFilter(f)}
                  className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${filter === f ? 'bg-white shadow-sm text-gray-800' : 'text-gray-400 hover:text-gray-600'}`}>
                  {f === 'pending'  && `Chờ duyệt${u.pending > 0 ? ` (${u.pending})` : ''}`}
                  {f === 'approved' && 'Đã duyệt'}
                  {f === 'rejected' && 'Từ chối'}
                  {f === 'all'      && 'Tất cả'}
                </button>
              ))}
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-gray-300" />
              <input value={search} onChange={e => setSearch(e.target.value)}
                placeholder="Tìm tên, email, phòng ban..."
                className="pl-9 pr-4 py-2 text-xs border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-200 w-64" />
            </div>
          </div>

          <div className="grid grid-cols-[1.2fr_1.8fr_1fr_1fr_1.4fr] gap-4 px-5 py-3 text-[10px] font-bold text-gray-400 uppercase tracking-wider bg-gray-50/60">
            <span>Họ tên</span><span>Email</span><span>Phòng ban</span><span>Trạng thái</span><span className="text-right">Hành động</span>
          </div>

          {loading ? (
            <div className="text-center py-14 text-sm text-gray-400">Đang tải...</div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-14 text-sm text-gray-400">
              {search ? 'Không tìm thấy thành viên phù hợp' : 'Không có thành viên nào'}
            </div>
          ) : filtered.map(u => (
            <div key={u._id} className="grid grid-cols-[1.2fr_1.8fr_1fr_1fr_1.4fr] gap-4 px-5 py-4 items-center border-t border-gray-50 hover:bg-gray-50/50 transition-colors">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="h-8 w-8 rounded-full bg-indigo-100 text-indigo-600 text-[11px] font-bold flex items-center justify-center flex-shrink-0">
                  {u.fullName.split(' ').map((n: string) => n[0]).slice(-2).join('').toUpperCase()}
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-gray-800 truncate">{u.fullName}</p>
                  <p className="text-[10px] text-gray-400">{new Date(u.createdAt).toLocaleDateString('vi-VN')}</p>
                </div>
              </div>

              <p className="text-xs text-gray-500 truncate">{u.email}</p>
              <p className="text-xs text-gray-600">{u.department}</p>

              <div>
                <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-[10px] font-bold ${STATUS_META[u.status]?.cls}`}>
                  {STATUS_META[u.status]?.label || u.status}
                </span>
                {u.status === 'rejected' && u.rejectReason && (
                  <p className="text-[10px] text-red-400 mt-1 truncate" title={u.rejectReason}>{u.rejectReason}</p>
                )}
              </div>

              <div className="flex items-center justify-end gap-2">
                {u.status === 'pending' && (<>
                  <button onClick={() => approve(u._id)} disabled={actionId === u._id}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500 text-white text-xs font-semibold hover:bg-emerald-600 transition disabled:opacity-50">
                    <CheckCircle2 className="h-3.5 w-3.5" />{actionId === u._id ? '...' : 'Duyệt'}
                  </button>
                  <button onClick={() => setModal({ open: true, userId: u._id, name: u.fullName })}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-500 text-white text-xs font-semibold hover:bg-red-600 transition">
                    <XCircle className="h-3.5 w-3.5" /> Từ chối
                  </button>
                </>)}
                {u.status === 'approved' && (
                  <button onClick={() => revoke(u._id, u.fullName)} disabled={actionId === u._id}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-red-200 text-red-500 text-xs font-semibold hover:bg-red-50 transition disabled:opacity-50">
                    <XCircle className="h-3.5 w-3.5" />{actionId === u._id ? '...' : 'Thu hồi'}
                  </button>
                )}
                {u.status === 'rejected' && (
                  <button onClick={() => reset(u._id)} disabled={actionId === u._id}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-gray-200 text-gray-500 text-xs font-semibold hover:bg-gray-50 transition disabled:opacity-50">
                    <RotateCcw className="h-3.5 w-3.5" />{actionId === u._id ? '...' : 'Xét lại'}
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </main>

      {/* Reject Modal */}
      {modal.open && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-xl">
            <h3 className="text-base font-bold text-gray-800 mb-1">Từ chối tài khoản</h3>
            <p className="text-sm text-gray-500 mb-4">
              Từ chối <span className="font-semibold text-gray-700">{modal.name}</span>?
              Thành viên sẽ nhận thông báo và không thể đặt phòng.
            </p>
            <div className="mb-4">
              <label className="block text-xs font-bold text-gray-500 mb-1.5 uppercase tracking-wide">Lý do (tuỳ chọn)</label>
              <textarea value={rejectReason} onChange={e => setRejectReason(e.target.value)} rows={3}
                placeholder="Nhập lý do để thông báo cho thành viên..."
                className="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-xl resize-none focus:outline-none focus:ring-2 focus:ring-indigo-200" />
            </div>
            <div className="flex gap-3">
              <button onClick={() => { setModal({ open: false, userId: '', name: '' }); setRejectReason('') }}
                className="flex-1 h-10 rounded-xl border border-gray-200 text-sm font-semibold text-gray-600 hover:bg-gray-50 transition">Huỷ</button>
              <button onClick={confirmReject} disabled={!!actionId}
                className="flex-1 h-10 rounded-xl bg-red-500 text-white text-sm font-semibold hover:bg-red-600 transition disabled:opacity-60">
                {actionId ? '...' : 'Xác nhận từ chối'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}

/* ─────────────────────────────────────────────────────────────
   TAB 2: QUẢN LÝ ĐẶT PHÒNG
───────────────────────────────────────────────────────────── */
function BookingsTab() {
  const today = new Date().toISOString().split('T')[0]
  const [date,     setDate]     = useState(today)
  const [room,     setRoom]     = useState<string>('')
  const [bookings, setBookings] = useState<any[]>([])
  const [loading,  setLoading]  = useState(true)
  const [deleteModal, setDeleteModal] = useState<{ open: boolean; booking: any }>({ open: false, booking: null })
  const [deleteReason, setDeleteReason] = useState('')
  const [deleting, setDeleting] = useState(false)

  useEffect(() => { load() }, [date, room])

  async function load() {
    setLoading(true)
    const res = await adminGetBookingsApi({ date, room: room || undefined })
    if (res.success) setBookings(res.data)
    setLoading(false)
  }

  async function confirmDelete() {
    setDeleting(true)
    const res = await adminDeleteBookingApi(deleteModal.booking._id || deleteModal.booking.id, deleteReason)
    if (!res.success) toast.error(res.message)
    else toast.success('Đã huỷ lịch đặt phòng!')
    setDeleteModal({ open: false, booking: null }); setDeleteReason('')
    await load()
    setDeleting(false)
  }

  const tang5 = bookings.filter(b => b.room === 'tang5')
  const tang6 = bookings.filter(b => b.room === 'tang6')

  function bookingStatus(b: any) {
    const now   = new Date()
    const pad   = (n: number) => String(n).padStart(2,'0')
    const todayStr = `${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())}`
    const nowMin = now.getHours() * 60 + now.getMinutes()
    const toMin  = (t: string) => { const [h,m] = t.split(':').map(Number); return h*60+m }
    if (b.date > todayStr) return 'upcoming'
    if (b.date < todayStr) return 'done'
    if (nowMin < toMin(b.timeFrom)) return 'upcoming'
    if (nowMin >= toMin(b.timeTo))  return 'done'
    return 'ongoing'
  }

  return (
    <>
      <header className="h-14 bg-white border-b border-gray-100 px-6 flex items-center justify-between flex-shrink-0">
        <h1 className="text-base font-bold text-gray-800">Quản lý đặt phòng</h1>
        <span className="text-xs text-gray-400">Xem và huỷ lịch đặt phòng của thành viên</span>
      </header>

      <main className="flex-1 p-6 overflow-auto">
        {/* Filters */}
        <div className="bg-white rounded-2xl border border-gray-100 p-4 mb-6 flex items-center gap-4 flex-wrap">
          <div className="flex items-center gap-2">
            <button onClick={() => setDate(addDays(date, -1))} className="p-1.5 rounded-lg text-gray-400 hover:text-gray-600 hover:bg-gray-50 transition"><ChevronLeft className="h-4 w-4" /></button>
            <input type="date" value={date} onChange={e => setDate(e.target.value)}
              className="px-3 py-1.5 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-200" />
            <button onClick={() => setDate(addDays(date, 1))} className="p-1.5 rounded-lg text-gray-400 hover:text-gray-600 hover:bg-gray-50 transition"><ChevronRight className="h-4 w-4" /></button>
            <button onClick={() => setDate(today)} className="px-3 py-1.5 text-xs font-semibold text-indigo-600 bg-indigo-50 rounded-lg hover:bg-indigo-100 transition">Hôm nay</button>
          </div>
          <div className="flex gap-1 bg-gray-50 p-1 rounded-xl ml-auto">
            {[{ val: '', label: 'Tất cả' }, { val: 'tang5', label: 'Phòng lớn (T5)' }, { val: 'tang6', label: 'Phòng nhỏ (T6)' }].map(r => (
              <button key={r.val} onClick={() => setRoom(r.val)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${room === r.val ? 'bg-white shadow-sm text-gray-800' : 'text-gray-400 hover:text-gray-600'}`}>
                {r.label}
              </button>
            ))}
          </div>
        </div>

        {/* Stats strip */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          {[
            { label: 'Tổng lịch đặt', val: bookings.length, cls: 'text-gray-700' },
            { label: 'Phòng lớn (T5)', val: tang5.length, cls: 'text-indigo-600' },
            { label: 'Phòng nhỏ (T6)', val: tang6.length, cls: 'text-violet-600' },
          ].map(s => (
            <div key={s.label} className="bg-white rounded-2xl border border-gray-100 p-4 text-center">
              <p className={`text-2xl font-bold ${s.cls}`}>{s.val}</p>
              <p className="text-xs text-gray-400 mt-0.5">{s.label}</p>
            </div>
          ))}
        </div>

        {/* Booking list */}
        <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
          <div className="grid grid-cols-[1.5fr_1.2fr_1fr_1.2fr_1fr_auto] gap-4 px-5 py-3 text-[10px] font-bold text-gray-400 uppercase tracking-wider bg-gray-50/60">
            <span>Người đặt</span><span>Lý do</span><span>Phòng</span><span>Thời gian</span><span>Trạng thái</span><span>Huỷ</span>
          </div>

          {loading ? (
            <div className="text-center py-14 text-sm text-gray-400">Đang tải...</div>
          ) : bookings.length === 0 ? (
            <div className="text-center py-14 text-sm text-gray-400">Không có lịch đặt nào trong ngày này</div>
          ) : bookings.map(b => {
            const st = b.status || bookingStatus(b)
            return (
              <div key={b._id} className="grid grid-cols-[1.5fr_1.2fr_1fr_1.2fr_1fr_auto] gap-4 px-5 py-4 items-center border-t border-gray-50 hover:bg-gray-50/50 transition-colors">
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-gray-800 truncate">{b.userName}</p>
                  <p className="text-[10px] text-gray-400 truncate">{b.userId?.department || b.team || ''}</p>
                </div>
                <p className="text-xs text-gray-600 truncate" title={b.reason}>{b.reason}</p>
                <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-[10px] font-bold w-fit ${
                  b.room === 'tang5' ? 'bg-indigo-100 text-indigo-700' : 'bg-violet-100 text-violet-700'
                }`}>
                  {b.room === 'tang5' ? 'Tầng 5' : 'Tầng 6'}
                </span>
                <p className="text-xs text-gray-600">{b.date}<br /><span className="text-[10px] text-gray-400">{b.timeFrom}–{b.timeTo}</span></p>
                <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-[10px] font-bold w-fit ${BOOKING_STATUS[st]?.cls || 'bg-gray-100 text-gray-500'}`}>
                  {BOOKING_STATUS[st]?.label || st}
                </span>
                {st !== 'done' ? (
                  <button onClick={() => setDeleteModal({ open: true, booking: b })}
                    className="p-1.5 rounded-lg text-red-400 hover:text-red-600 hover:bg-red-50 transition" title="Huỷ lịch đặt">
                    <Trash2 className="h-4 w-4" />
                  </button>
                ) : (
                  <span className="w-7 h-7" />
                )}
              </div>
            )
          })}
        </div>
      </main>

      {/* Delete Booking Modal */}
      {deleteModal.open && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-xl">
            <h3 className="text-base font-bold text-gray-800 mb-1">Huỷ lịch đặt phòng</h3>
            <p className="text-sm text-gray-500 mb-1">
              Huỷ lịch đặt của <span className="font-semibold text-gray-700">{deleteModal.booking?.userName}</span>?
            </p>
            <p className="text-xs text-gray-400 mb-4">
              {deleteModal.booking?.reason} · {deleteModal.booking?.date} · {deleteModal.booking?.timeFrom}–{deleteModal.booking?.timeTo}
            </p>
            <div className="mb-4">
              <label className="block text-xs font-bold text-gray-500 mb-1.5 uppercase tracking-wide">Lý do huỷ (tuỳ chọn)</label>
              <textarea value={deleteReason} onChange={e => setDeleteReason(e.target.value)} rows={2}
                placeholder="Thành viên sẽ nhận thông báo với lý do này..."
                className="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-xl resize-none focus:outline-none focus:ring-2 focus:ring-red-200" />
            </div>
            <div className="flex gap-3">
              <button onClick={() => { setDeleteModal({ open: false, booking: null }); setDeleteReason('') }}
                className="flex-1 h-10 rounded-xl border border-gray-200 text-sm font-semibold text-gray-600 hover:bg-gray-50 transition">Không</button>
              <button onClick={confirmDelete} disabled={deleting}
                className="flex-1 h-10 rounded-xl bg-red-500 text-white text-sm font-semibold hover:bg-red-600 transition disabled:opacity-60">
                {deleting ? '...' : 'Xác nhận huỷ'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}

/* ─────────────────────────────────────────────────────────────
   TAB 3: THỐNG KÊ / BÁO CÁO
───────────────────────────────────────────────────────────── */
function ReportTab() {
  const today = new Date().toISOString().split('T')[0]
  const monthStart = today.slice(0, 8) + '01'
  const [from,    setFrom]    = useState(monthStart)
  const [to,      setTo]      = useState(today)
  const [report,  setReport]  = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [stats,   setStats]   = useState<any>(null)

  useEffect(() => { loadStats(); loadReport() }, [])

  async function loadStats() {
    const res = await adminGetStatsApi()
    if (res.success) setStats(res.data)
  }

  async function loadReport() {
    setLoading(true)
    const res = await adminGetReportApi(from, to)
    if (res.success) setReport(res.data)
    setLoading(false)
  }

  const tang5Pct = report ? Math.round((report.byRoom?.tang5 || 0) / Math.max(report.total, 1) * 100) : 0
  const tang6Pct = report ? Math.round((report.byRoom?.tang6 || 0) / Math.max(report.total, 1) * 100) : 0

  return (
    <>
      <header className="h-14 bg-white border-b border-gray-100 px-6 flex items-center justify-between flex-shrink-0">
        <h1 className="text-base font-bold text-gray-800">Thống kê & Báo cáo</h1>
        <span className="text-xs text-gray-400">Phân tích sử dụng phòng họp</span>
      </header>

      <main className="flex-1 p-6 overflow-auto space-y-6">
        {/* Overall stats */}
        {stats && (
          <div className="grid grid-cols-4 gap-4">
            {[
              { label: 'Tổng thành viên',  val: stats.users?.total    || 0, Icon: Users,        c: 'text-gray-600',    bg: 'bg-gray-50'    },
              { label: 'Đã được duyệt',    val: stats.users?.approved || 0, Icon: CheckCircle2, c: 'text-emerald-600', bg: 'bg-emerald-50' },
              { label: 'Tổng lịch đặt',   val: stats.bookings?.total || 0, Icon: CalendarDays, c: 'text-indigo-600',  bg: 'bg-indigo-50'  },
              { label: 'Đặt hôm nay',     val: stats.bookings?.today || 0, Icon: TrendingUp,   c: 'text-violet-600',  bg: 'bg-violet-50'  },
            ].map(s => (
              <div key={s.label} className="bg-white rounded-2xl border border-gray-100 p-4 flex items-center gap-3">
                <div className={`h-10 w-10 rounded-xl ${s.bg} flex items-center justify-center flex-shrink-0`}>
                  <s.Icon className={`h-5 w-5 ${s.c}`} />
                </div>
                <div>
                  <p className="text-2xl font-bold text-gray-800">{s.val}</p>
                  <p className="text-xs text-gray-400 mt-0.5">{s.label}</p>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Date range filter */}
        <div className="bg-white rounded-2xl border border-gray-100 p-5">
          <p className="text-sm font-bold text-gray-700 mb-4 flex items-center gap-2"><Filter className="h-4 w-4" /> Lọc theo khoảng thời gian</p>
          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex items-center gap-2">
              <label className="text-xs text-gray-500 font-medium">Từ</label>
              <input type="date" value={from} onChange={e => setFrom(e.target.value)}
                className="px-3 py-1.5 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-200" />
            </div>
            <div className="flex items-center gap-2">
              <label className="text-xs text-gray-500 font-medium">Đến</label>
              <input type="date" value={to} onChange={e => setTo(e.target.value)}
                className="px-3 py-1.5 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-200" />
            </div>
            <button onClick={loadReport} disabled={loading}
              className="px-4 py-1.5 bg-indigo-600 text-white text-sm font-semibold rounded-lg hover:bg-indigo-700 transition disabled:opacity-50">
              {loading ? 'Đang tải...' : 'Xem báo cáo'}
            </button>
          </div>
        </div>

        {report && (
          <>
            {/* Summary cards */}
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-white rounded-2xl border border-gray-100 p-5">
                <p className="text-xs text-gray-400 font-medium mb-1">Tổng lịch đặt</p>
                <p className="text-3xl font-bold text-gray-800">{report.total}</p>
                <p className="text-xs text-gray-400 mt-1">trong khoảng đã chọn</p>
              </div>
              <div className="bg-white rounded-2xl border border-gray-100 p-5">
                <p className="text-xs text-gray-400 font-medium mb-1">Tổng giờ họp</p>
                <p className="text-3xl font-bold text-indigo-600">{report.totalHours}h</p>
                <p className="text-xs text-gray-400 mt-1">thời gian sử dụng</p>
              </div>
              <div className="bg-white rounded-2xl border border-gray-100 p-5">
                <p className="text-xs text-gray-400 font-medium mb-1">Phòng dùng nhiều nhất</p>
                <p className="text-lg font-bold text-gray-800 mt-1">
                  {(report.byRoom?.tang5 || 0) >= (report.byRoom?.tang6 || 0) ? 'Phòng lớn (T5)' : 'Phòng nhỏ (T6)'}
                </p>
                <p className="text-xs text-gray-400 mt-1">
                  T5: {report.byRoom?.tang5 || 0} · T6: {report.byRoom?.tang6 || 0} lượt
                </p>
              </div>
            </div>

            {/* Room usage bar */}
            <div className="bg-white rounded-2xl border border-gray-100 p-5">
              <p className="text-sm font-bold text-gray-700 mb-4 flex items-center gap-2"><Building2 className="h-4 w-4" /> Tỉ lệ sử dụng theo phòng</p>
              <div className="space-y-4">
                {[
                  { name: 'Phòng họp lớn (Tầng 5)', count: report.byRoom?.tang5 || 0, pct: tang5Pct, color: 'bg-indigo-500' },
                  { name: 'Phòng họp nhỏ (Tầng 6)', count: report.byRoom?.tang6 || 0, pct: tang6Pct, color: 'bg-violet-500' },
                ].map(r => (
                  <div key={r.name}>
                    <div className="flex items-center justify-between mb-1.5">
                      <p className="text-sm font-medium text-gray-700">{r.name}</p>
                      <p className="text-sm font-bold text-gray-800">{r.count} lượt ({r.pct}%)</p>
                    </div>
                    <div className="h-2.5 bg-gray-100 rounded-full overflow-hidden">
                      <div className={`h-full ${r.color} rounded-full transition-all duration-500`} style={{ width: `${r.pct}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Top users */}
            {report.topUsers?.length > 0 && (
              <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
                <div className="px-5 py-4 border-b border-gray-50">
                  <p className="text-sm font-bold text-gray-700">Top thành viên đặt phòng nhiều nhất</p>
                </div>
                <div className="grid grid-cols-[auto_1fr_1fr_auto_auto] gap-4 px-5 py-3 text-[10px] font-bold text-gray-400 uppercase tracking-wider bg-gray-50/60">
                  <span>#</span><span>Họ tên</span><span>Phòng ban</span><span className="text-right">Số lượt</span><span className="text-right">Giờ họp</span>
                </div>
                {report.topUsers.map((u: any, i: number) => (
                  <div key={u.userId} className="grid grid-cols-[auto_1fr_1fr_auto_auto] gap-4 px-5 py-3.5 items-center border-t border-gray-50">
                    <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${i === 0 ? 'bg-amber-100 text-amber-700' : i === 1 ? 'bg-gray-100 text-gray-600' : i === 2 ? 'bg-orange-100 text-orange-600' : 'bg-gray-50 text-gray-400'}`}>{i+1}</span>
                    <p className="text-sm font-semibold text-gray-800">{u.name}</p>
                    <p className="text-xs text-gray-500">{u.department}</p>
                    <p className="text-sm font-bold text-indigo-600 text-right">{u.count} lượt</p>
                    <p className="text-xs text-gray-400 text-right">{(u.minutes / 60).toFixed(1)}h</p>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </main>
    </>
  )
}
